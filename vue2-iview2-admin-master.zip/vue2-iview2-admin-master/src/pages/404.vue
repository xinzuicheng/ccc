<template>
    <p style="font-size:20px;text-align: center;color:rgb(192, 204, 218);">404</p>
</template>